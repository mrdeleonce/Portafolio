﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    internal class Creditos
    {
        public void creditos()
        {

            Console.WriteLine("-----------------------------------------------------------------");
            Console.WriteLine("Créditos:");
            Console.WriteLine("");
            Console.WriteLine("Planificacion de horarios de jornadas laborales un una empresa");
            Console.WriteLine("");
            Console.WriteLine("Fecha de creacion: 20 de Octubre del 2023");
            Console.WriteLine("");
            Console.WriteLine("El tiempo estimado de creacion del programa fue de 20 Horas");
            Console.WriteLine("");
            Console.WriteLine("Prgrama creado por:");
            Console.WriteLine("");
            Console.WriteLine("Derick Pinto");
            Console.WriteLine("1065723");
            Console.WriteLine("Ingenieria Industrial");
            Console.WriteLine("");
            Console.WriteLine("Nicolas Rivas");
            Console.WriteLine("1045123");
            Console.WriteLine("Ingenieria Industrial");
            Console.WriteLine("");
            Console.WriteLine("Maria Reneé del leon");
            Console.WriteLine("1066423");
            Console.WriteLine("Ingenieria Industrial");
            Console.WriteLine("");


            string regresarMenuPrincipal;
            do
            {
                Console.WriteLine("Si desea regresar al Menú Principal seleccione la opcion 1");
                Console.WriteLine("Si desea salir del programa seleccione la opcion 2");
                regresarMenuPrincipal = Console.ReadLine();

                if (regresarMenuPrincipal.ToLower() == "1")
                {
                    Console.Clear();
                    MenuPrincipal.Menu_1();
                    break;
                }
                else if (regresarMenuPrincipal.ToLower() == "2")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Opción no válida. Introduce opcion 1 u opcion 2.");
                }
            } while (true);

        }
    }
}
