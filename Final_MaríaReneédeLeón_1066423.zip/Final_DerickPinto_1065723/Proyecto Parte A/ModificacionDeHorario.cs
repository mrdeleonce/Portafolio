﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    internal class ModificacionDeHorario
    {
        public void Modificaciondehorarios()
        {

            int opcion_3, opcion_3_1, opcion_3_1_1;
           
            try
            {
                do
                {



                    Console.WriteLine("Modificación de horario");
                    Console.WriteLine("");
                    Console.WriteLine("Seleccione un tipo de jorada deseada");
                    Console.WriteLine("");
                    Console.WriteLine("1. Diurna");
                    Console.WriteLine("2. Nocturna");
                    Console.WriteLine("3. Mixto");
                    Console.WriteLine("4. Regresar al menu principal");
                    Console.WriteLine("5. Salir del programa");
                    opcion_3 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("");

                    switch (opcion_3)
                    {
                        case 1:
                            Console.Clear();
                            Console.WriteLine("Usted seleecióno el tipo de jornada DIURNA");
                            Console.WriteLine("");
                            Console.WriteLine("Seleccione la distribuicion de sus horas; sus horas laborales deberan estar ");
                            Console.WriteLine("comprendidas por no mas de 8 horas al dia, en el lapso de las 6:00am a las 6:00pm ");
                            Console.WriteLine("");
                            Console.WriteLine("1. De 6:00am a 2:00pm");
                            Console.WriteLine("2. De 7:00am a 3:00pm");
                            Console.WriteLine("3. De 8:00am a 4:00pm");
                            Console.WriteLine("4. De 9:00am a 5:00pm");
                            Console.WriteLine("5. De 10:00am a 6:00pm");
                            opcion_3_1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("");



                            switch (opcion_3_1)
                            {
                                case 1:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 6:00am a 2:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 6:00am a 2:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");

                                                }

                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");
                                                //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado

                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 6:00am a 2:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");

                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 2:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 7:00am a 3:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 7:00am a 3:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 7:00am a 3:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 3:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 8:00am a 4:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 8:00am a 4:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 8:00am a 4:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 4:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 9:00am a 5:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 9:00am a 5:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 9:00am a 5:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 5:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 10:00am a 6:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 10:00am a 6:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Diurna, en horario de 10:00am a 6:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                default:
                                    Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Vuelva a empezar"); ;
                                    Console.ReadKey();
                                    Console.Clear();
                                    MenuPrincipal.ModificarHorario();
                                    break;
                            }
                            break;

                        case 2:
                            Console.Clear();
                            Console.WriteLine("Usted seleecióno el tipo de jornada NOCTURNA");
                            Console.WriteLine("");
                            Console.WriteLine("Seleccione la distribuicion de sus horas; sus horas laborales deberan estar ");
                            Console.WriteLine("comprendidas por no mas de 6 horas, en el lapso de las 6:00pm a las 6:00am del dia siguiente");
                            Console.WriteLine("");
                            Console.WriteLine("1. De 6:00pm a 12:00am");
                            Console.WriteLine("2. De 7:00pm a 1:00am");
                            Console.WriteLine("3. De 8:00pm a 2:00am");
                            Console.WriteLine("4. De 9:00pm a 3:00am");
                            Console.WriteLine("5. De 10:00pm a 4:00am");
                            Console.WriteLine("6. De 11:00pm a 5:00am");
                            Console.WriteLine("7. De 12:00am a 6:00am");
                            opcion_3_1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("");



                            switch (opcion_3_1)
                            {
                                case 1:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 6:00pm a 12:00am");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 10 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 8 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 6:00pm a 12:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 6:00pm a 12:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 2:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 7:00pm a 1:00am");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 10 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 8 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 7:00pm a 1:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 7:00pm a 1:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 3:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 8:00pm a 2:00am");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 10 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 8 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 8:00pm a 2:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 8:00pm a 2:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 4:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 9:00pm a 3:00am");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 10 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 8 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 9:00pm a 3:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 9:00pm a 3:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 5:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 10:00pm a 4:00am");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 10 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 8 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 10:00pm a 4:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 10:00pm a 4:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 6:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 11:00pm a 5:00am");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 10 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 8 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 11:00pm a 5:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 11:00pm a 5:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 7:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 12:00am a 6:00am");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 10 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 8 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 10 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 10 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 12:00am a 6:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 8 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 8 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 12:00am a 6:00Pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                default:
                                    Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Vuelva a empezar"); ;
                                    Console.ReadKey();
                                    Console.Clear();
                                    MenuPrincipal.ModificarHorario();
                                    break;
                            }
                            break;

                        case 3:
                            Console.Clear();
                            Console.WriteLine("Usted seleecióno el tipo de jornada MIXTO");
                            Console.WriteLine("");
                            Console.WriteLine("Seleccione la distribuicion de sus horas; sus horas laborales deberan estar ");
                            Console.WriteLine("comprendidas por no mas de 7 horas al dia, debido a que ya estan las horas establecidas");
                            Console.WriteLine("como jornada nocturna");
                            Console.WriteLine("");
                            Console.WriteLine("1. De 10:00am a 2:00pm y de 7:00pm a 10:00pm");
                            Console.WriteLine("2. De 6:00am a 11:00am y de 7:00pm a 9:00pm");
                            Console.WriteLine("3. De 8:00am a 11:00am y de 6:00pm a 10:00pm");
                            opcion_3_1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("");

                            switch (opcion_3_1)
                            {
                                case 1:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 10:00am a 2:00pm y de 7:00pm a 10:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 10:00am a 2:00pm y de 7:00pm a 10:00pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 10:00am a 2:00pm y de 7:00pm a 10:00pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 2:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 6:00am a 11:00am y de 7:00pm a 9:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 6:00am a 11:00am y de 7:00pm a 9:00pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 6:00am a 11:00am y de 7:00pm a 9:00pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                case 3:
                                    Console.Clear();
                                    Console.WriteLine("Las horas que usted selecciono fueron de 8:00am a 11:00am y de 6:00pm a 10:00pm");
                                    Console.WriteLine("");
                                    Console.WriteLine("Si usted desea optar a vacaciones en su primer año trabajando en la empresa debera trabajar un minimo de 150 dias");
                                    Console.WriteLine("Seleccione la fecha en la que desea comenzar a trabajar");
                                    Console.WriteLine("");
                                    Console.WriteLine("1. Del 10 de Enero al 9 de Junio");
                                    Console.WriteLine("2. Del 10 de Junio al 7 de Noviembre");
                                    opcion_3_1_1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    switch (opcion_3_1_1)
                                    {
                                        case 1:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Enero hasta el 9 de Junio");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 9 de Junio");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 303 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 8:00am a 11:00am y de 6:00pm a 10:00pm,");
                                                    Console.WriteLine($"trabajando del 10 Enero hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 9 de Junio, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                            Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                            Console.WriteLine("");
                                            Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                            try
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Usted selecciono empezar a trabajar desde el 10 de Junio hasta el 7 de Noviembre");
                                                Console.WriteLine("Usted podra empezar sus vacaciones a partir de del dia 7 de Noviembre");
                                                Console.WriteLine("");
                                                Console.WriteLine("¿Como desea organizar sus fechas para poder tomar sus vacaciones?");
                                                Console.WriteLine("Ingresa el numero de dias que desea tomar de vacaciones, eliga un número del 1 al 10: ");  //aqui
                                                int DiasVacaciones = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("");

                                                // Verifica que el número esté en el rango permitido
                                                if (DiasVacaciones >= 1 && DiasVacaciones <= 10)
                                                {
                                                    // Resta el número elegido al resultado de 303
                                                    int resultado = 154 - DiasVacaciones;

                                                    // Muestra el resultado
                                                    Console.WriteLine($"Su horario final se comprende de la siguiente forma: Jornada Nocturna, en horario de 8:00am a 11:00am y de 6:00pm a 10:00pm,");
                                                    Console.WriteLine($"trabajando del 10 Junio hasta final de año, y sus {DiasVacaciones} dias de vacaciones seleccionados tomaran vigencia ");
                                                    Console.WriteLine($"a partir del 7 de Noviembre, por lo que usted trabajaria, {resultado} dias de lo que queda del año, sin tomar");
                                                    Console.WriteLine("en cuenta dias festivos y feriados.");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El número ingresado no está en el rango permitido (1-10).");
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Entrada no válida. Vuelva a empezar.");
                                            }                                                                                                                                 //asta aqui

                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                        default:
                                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta"); ;
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    break;

                                default:
                                    Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Vuelva a empezar"); ;
                                    Console.ReadKey();
                                    Console.Clear();
                                    MenuPrincipal.ModificarHorario();
                                    break;
                            }
                            break;

                        case 4:
                            Console.Clear();
                            MenuPrincipal.Menu_1();
                            break;

                        case 5:
                            Console.Clear();
                            Environment.Exit(0);
                            break;

                        default:
                            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Vuelva a empezar"); ;
                            Console.ReadKey();
                            Console.Clear();
                            MenuPrincipal.ModificarHorario();
                            break;
                    }

                    string regresarMenuAnterior;
                    do
                    {

                        Console.WriteLine("Si desea modificar otro horario seleccione la opcion 1");
                        Console.WriteLine("Si desea regresar al menu principal seleccione la opcion 2");
                        Console.WriteLine("Si salir del programa seleccione la opcion 3");
                        regresarMenuAnterior = Console.ReadLine();

                        if (regresarMenuAnterior.ToLower() == "1")
                        {
                            Console.Clear();
                            Modificaciondehorarios();
                            break;
                        }
                        else if (regresarMenuAnterior.ToLower() == "2")
                        {
                            Console.Clear();
                            MenuPrincipal.Menu_1();
                            break;
                        }
                        else if (regresarMenuAnterior.ToLower() == "3")
                        {
                            Environment.Exit(0);
                        }
                        else
                        {
                            Console.WriteLine("Opción no válida. Introdusca una de las opciones que le aparece en la pantalla.");
                            Console.WriteLine("");
                        }

                    } while (true);

                } while (true);
            }
            catch
            {
                Console.WriteLine("");
                Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Vuleva a empezar");
                Console.ReadKey();
                Console.Clear();
                Modificaciondehorarios();
            }
        }
    }
}
 