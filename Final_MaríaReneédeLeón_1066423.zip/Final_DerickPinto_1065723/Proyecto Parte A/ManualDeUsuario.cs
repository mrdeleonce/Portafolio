﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    internal class ManualDeUsuario
    {
        public void Manualdeusuario ()
        {
            Console.WriteLine("-------------------------------------------------------");
            Console.WriteLine("Manual de usuario:");
            Console.WriteLine("");
            Console.WriteLine("I Opciones que posee el programa");
            Console.WriteLine("1. proceso principal");
            Console.WriteLine("2. Manual de usuario");
            Console.WriteLine("3. Creditos");
            Console.WriteLine("4. Salir");
            Console.WriteLine("");
            Console.WriteLine("II Pasos a seguir para mostrar la solucion");
            Console.WriteLine("1. Seleccionar la opcion de proceso principal");
            Console.WriteLine("2. Seleccionar opcion por opcion hasta leer todas las descripciones que se les brindara");
            Console.WriteLine("3. Una vez leida las descripciones detalladas que les brindara las primeras tres opciones");
            Console.WriteLine("   seleccionar la cuarta opcion para Modificar el horario deseado");
            Console.WriteLine("4. Complete su modificacion del horario deseado");
            Console.WriteLine("5. Podra decidir si usted desea regresar al menu anterior o al menu principal");
            Console.WriteLine("");
            Console.WriteLine("III Proposito de este programa");
            Console.WriteLine("El proposito de este programa 'Planificacion de horarios de jornadas laborales un una empresa' tiene como objetivo: ");
            Console.WriteLine("Realizar un programa en el cual el trabajador pueda crear y organizar su horario basandose,");
            Console.WriteLine("en las propuestas que se le daran.");
            Console.WriteLine("");


            string regresarMenuPrincipal;
            do
            {
                Console.WriteLine("Si desea regresar al Menú Principal seleccione la opcion 1");
                Console.WriteLine("Si desea salir del programa seleccione la opcion 2");
                regresarMenuPrincipal = Console.ReadLine();

                if (regresarMenuPrincipal.ToLower() == "1")
                {
                    Console.Clear();
                    MenuPrincipal.Menu_1();
                    break;
                }
                else if (regresarMenuPrincipal.ToLower() == "2")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Opción no válida. Introduce opcion 1 u opcion 2.");
                }
            } while (true);

          

        }

       
    }
}
