﻿using Proyecto_Final;
using System;
using System.Xml.Linq;

public class MenuPrincipal
{
    public static void Main(string[] args)
           {
                Menu_1();
           }

    public static void Menu_1()
           {
                int opcion_1;
        try
        {
            do
            {
                Console.WriteLine("Planificación de horarios de jornadas laborales en una empresa");
                Console.WriteLine("");
                Console.WriteLine("1. Proceso principal");
                Console.WriteLine("2. Manual de usuario");
                Console.WriteLine("3. Créditos");
                Console.WriteLine("4. Salir");
                Console.WriteLine("");
                Console.WriteLine("Seleccione una opción: ");
                opcion_1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                switch (opcion_1)
                {
                    case 1:
                        Console.Clear();
                        Menu_2();
                        break;

                    case 2:
                        Console.Clear();
                        ManualDeUsuario();
                        break;

                    case 3:
                        Console.Clear();
                        Creditos();
                        break;

                    case 4:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta.");
                        Console.ReadKey();
                        Console.Clear();
                        Menu_1();
                        break;
                }


                string regresarMenuPrincipal;
                do
                {
                    Console.WriteLine("¿Desea regresar al Menú Principal? (si/no)");
                    regresarMenuPrincipal = Console.ReadLine();

                    if (regresarMenuPrincipal.ToLower() == "si")
                    {
                        Console.Clear();
                        break;
                    }
                    else if (regresarMenuPrincipal.ToLower() == "no")
                    {
                        Environment.Exit(0);
                    }
                    else
                    {
                        Console.WriteLine("Opción no válida. Introduce 'si' o 'no'.");
                    }
                } while (true);
            } while (true);
        }
        catch
        {
            Console.WriteLine("");
            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta");
            Console.ReadKey();
            Console.Clear();
            
            Menu_1();
           
        }
           }

    public static void Menu_2()
    {
        int opcion_2;
        try
        {

            do
            {
            
                Console.WriteLine("Planificación de horarios de jornadas laborales en una empresa");
                Console.WriteLine("");
                Console.WriteLine("1. Tipo de jornada");
                Console.WriteLine("2. Horas laborales");
                Console.WriteLine("3. Gestión de vacaciones");
                Console.WriteLine("4. Modificación de horario");
                Console.WriteLine("5. Regresar al menú principal");
                Console.WriteLine("");
                Console.WriteLine("Seleccione una opción: ");
                opcion_2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                switch (opcion_2)
                {
                    case 1:
                        Console.Clear();
                       
                        Console.WriteLine("Tipo de jornada");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion numero 1: Diurna");
                        Console.WriteLine("- Se ejecuta en un tiempo comprendido de las 6:00 y las 18:00 horas del día.");
                        Console.WriteLine("  Así mismo, la labor diurna normal es de 45 horas de TRABAJO EFECTIVO,");
                        Console.WriteLine("  equivalente a las 48 horas para efectos exclusivos del PAGO DE SALARIO");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion numero 2: Nocturna");
                        Console.WriteLine("- El horario se comprende a partir de las 18:00 y 6:00 horas del siguiente día.");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion numero 3: Mixto");
                        Console.WriteLine("- Se lleva a cabo entre las horas que comprende la jornada diurna y la");
                        Console.WriteLine("  nocturna. Si trabaja en jornada mixta y sobrepasa");
                        Console.WriteLine("  las cuatro o más horas, ya cuenta como nocturna.");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("Horas laborales");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion numero 1: Diurna");
                        Console.WriteLine("- Debera de trabajar como minimo 8 horas al dia durante la semana");
                        Console.WriteLine("  Sin exederese de las 8 horas o ser mayor de 48 horas semanalmente");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion numero 2: Nocturna");
                        Console.WriteLine("- No puede ser mayor de 6 horas diarias, ni exceder un total de 36 horas a la semana");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion numero 3: Mixto");
                        Console.WriteLine("- Debe ser de 7 horas diarias y tener un total semanal de 42 horas sin excederse de esa cifra");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();

                        Console.WriteLine("Gestión de vacaciones");
                        Console.WriteLine("Todo trabajador, sin excepción, tiene derecho a un período de vacaciones remuneradas después");
                        Console.WriteLine("de cada año de trabajo continuo al servicio de un mismo patrono, cuya duración mínima es de");
                        Console.WriteLine("10 días hábiles.");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion 1: ");
                        Console.WriteLine("- Trabajar del 10 de Enero hasta el 9 de Junio y obtener derecho a 10 dias de vacaciones");
                        Console.WriteLine("  que podra utilizar en cualquier momento a partir del dia 9 de junio");
                        Console.WriteLine("");
                        Console.WriteLine("Opcion 2:");
                        Console.WriteLine("- Trabajar del 10 de Junio hasta el 7 de Noviembre y obtener derecho a 10 dias de vacaciones");
                        Console.WriteLine("  que podra utilizar en cualquier momento a partir del dia 7 de Noviembre");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 4:
                        Console.Clear();
                        ModificarHorario();
                        break;
                    case 5:
                        Console.Clear();
                        Menu_1();
                        break;
                    default:
                        Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta.");
                        Console.ReadKey();
                        Console.Clear();
                        Menu_2();   
                        break;
                }


                string regresarMenuAnterior;
                do
                {
                    
                    Console.WriteLine("Si desea regresar al menu anterior seleccione la opcion 1"); 
                    Console.WriteLine("Si desea regresar al menu principal seleccione la opcion 2");
                    Console.WriteLine("Si salir del programa seleccione la opcion 3");
                    regresarMenuAnterior = Console.ReadLine();

                    if (regresarMenuAnterior.ToLower() == "1")
                    {
                        Console.Clear();
                        Menu_2();
                        break;
                    }
                    else if (regresarMenuAnterior.ToLower() == "2")
                    {
                        Console.Clear();
                        Menu_1();
                        break;
                    }
                    else if (regresarMenuAnterior.ToLower() == "3")
                    {
                        Environment.Exit(0);
                    }
                    else
                    {
                        Console.WriteLine("Opción no válida. Introdusca una de las opciones que le aparece en la pantalla.");
                        Console.WriteLine("");
                    }
                    
                } while (true);
               
            } while (true);
        }
        catch
        {
            Console.WriteLine("");
            Console.WriteLine("ERROR: Usted ha seleccionado una opción invalida. Seleccione una opción correcta");
            Console.ReadKey();
            Console.Clear();
            
            
            Menu_2();
            
        }
    }

    public static void ModificarHorario()
           {

        ModificacionDeHorario modificarHorario = new ModificacionDeHorario();
        modificarHorario.Modificaciondehorarios();

        
           }

    public static void ManualDeUsuario()
           {

        ManualDeUsuario manualDeUsuario = new ManualDeUsuario();
        manualDeUsuario.Manualdeusuario();


           }

    public static void Creditos()
           {

        Creditos creditos = new Creditos();
        creditos.creditos();

                
           }
}