﻿class Clase_Menu
{

    static void Main(string[] args)
    {
        Console.WriteLine("Mi programa de Dosificación de horas laborales");
        Console.WriteLine();
        Console.WriteLine("Seleccione una jornada laboral");
        Console.WriteLine("Menú Principal");
        Console.WriteLine("1. Matutina");
        Console.WriteLine("2. Vespertina");
        string SeleccionMenu;
        SeleccionMenu = Console.ReadLine();

        switch (SeleccionMenu)
        {
            case "1":
                Console.WriteLine("Ud selecciono: " + SeleccionMenu + " " + "Matutina");
                break;
            case "2":
                Console.WriteLine("Ud selecciono: " + SeleccionMenu + " " + "Vespertina");
                break;

            default:
                Console.WriteLine("Seleccione una opcion valida");
                break;
        }

        Console.ReadKey();

    }
}