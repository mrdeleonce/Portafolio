﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy " + Nombre);

        /* 
         Esto es un ejemplo de comentario
         */
        //otros comentarios

        Console.Write("Hola Mundo");
        Console.Write(" soy " + Nombre);
        Console.ReadKey();

        // See https://aka.ms/new-console-template for more information
        Console.WriteLine("Hola, Mundo soy María Reneé de León!");
    }
}