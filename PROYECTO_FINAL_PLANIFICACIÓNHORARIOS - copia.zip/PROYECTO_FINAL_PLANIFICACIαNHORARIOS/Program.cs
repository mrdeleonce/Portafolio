﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Menu_1();
    }

    static void Menu_1()
    {
        int opcion_1;

        do
        {
            Console.WriteLine("Planificación de horarios de jornadas laborales en una empresa");
            Console.WriteLine("");
            Console.WriteLine("1. Proceso principal");
            Console.WriteLine("2. Manual de usuario");
            Console.WriteLine("3. Créditos");
            Console.WriteLine("4. Salir");
            Console.WriteLine("");
            Console.WriteLine("Seleccione una opción: ");
            opcion_1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");

            switch (opcion_1)
            {
                case 1:
                    Menu_2();
                    break;

                case 2:
                    ManualDeUsuario();
                    break;

                case 3:
                    Creditos();
                    break;

                case 4:
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Usted ha seleccionado una opción invalida. Seleccione una opción correcta.");
                    break;
            }


            string regresarMenuPrincipal;
            do
            {
                Console.WriteLine("¿Desea regresar al Menú Principal? (si/no)");
                regresarMenuPrincipal = Console.ReadLine();

                if (regresarMenuPrincipal.ToLower() == "si")
                {
                    Console.Clear();
                    break;
                }
                else if (regresarMenuPrincipal.ToLower() == "no")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Opción no válida. Introduce 'si' o 'no'.");
                }
            } while (true);
        } while (true);
    }

    static void Menu_2()
    {
        int opcion_2;

        do
        {
            Console.WriteLine("-----------------------------------------------------------------");
            Console.WriteLine("Planificación de horarios de jornadas laborales en una empresa");
            Console.WriteLine("");
            Console.WriteLine("1. Tipo de jornada");
            Console.WriteLine("2. Horas laborales");
            Console.WriteLine("3. Gestión de vacaciones");
            Console.WriteLine("4. Modificación de horario");
            Console.WriteLine("5. Regresar al menú anterior");
            Console.WriteLine("");
            Console.WriteLine("Seleccione una opción: ");
            opcion_2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");

            switch (opcion_2)
            {
                case 1:
                    Console.WriteLine("-----------------------------------------------------------------");
                    Console.WriteLine("Tipo de jornada");
                    Console.WriteLine("");
                    Console.ReadKey();
                    Console.Clear();
                    break;
                case 2:
                    Console.WriteLine("-----------------------------------------------------------------");
                    Console.WriteLine("Horas laborales");
                    Console.WriteLine("");
                    Console.ReadKey();
                    Console.Clear();
                    break;
                case 3:
                    Console.WriteLine("-----------------------------------------------------------------");
                    Console.WriteLine("Gestión de vacaciones");
                    Console.WriteLine("");
                    Console.ReadKey();
                    Console.Clear();
                    break;
                case 4:
                    ModificarHorario();
                    break;
                case 5:
                    Console.Clear();
                    Menu_1();
                    break;
                default:
                    Console.WriteLine("Usted ha seleccionado una opción invalida. Seleccione una opción correcta.");
                    break;
            }


            string regresarMenuAnterior;
            do
            {
                Console.WriteLine("¿Desea regresar al Menú Anterior? (si/no)");
                regresarMenuAnterior = Console.ReadLine();

                if (regresarMenuAnterior.ToLower() == "si")
                {
                    Console.Clear();
                    break;
                }
                else if (regresarMenuAnterior.ToLower() == "no")
                {

                    string regresarMenuPrincipal;
                    do
                    {
                        Console.WriteLine("¿Desea regresar al Menú Principal? (si/no)");
                        regresarMenuPrincipal = Console.ReadLine();

                        if (regresarMenuPrincipal.ToLower() == "si")
                        {
                            Console.Clear();
                            Menu_1();
                            break;
                        }
                        else if (regresarMenuPrincipal.ToLower() == "no")
                        {
                            Environment.Exit(0);
                        }
                        else
                        {
                            Console.WriteLine("Opción no válida. Introduce 'si' o 'no'.");
                        }
                    } while (true);
                }
                else
                {
                    Console.WriteLine("Opción no válida. Introduce 'si' o 'no'.");
                }
            } while (true);
        } while (true);
    }

    static void ModificarHorario()
    {
        int opcion_3;

        Console.WriteLine("-----------------------------------------------------------------");
        Console.WriteLine("Modificación de horario");
        Console.WriteLine("");
        Console.WriteLine("1. Tipo de jornada");
        Console.WriteLine("2. Horas laborales");
        Console.WriteLine("3. Gestión de vacaciones");
        Console.WriteLine("4. Regresar al menú anterior");
        Console.WriteLine("");
        Console.WriteLine("Seleccione una opción: ");
        opcion_3 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("");

        switch (opcion_3)
        {
            case 1:
                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine("Modificación tipo de jornada");
                Console.WriteLine("");
                Console.ReadKey();
                Console.Clear();
                ModificarHorario();
                break;

            case 2:
                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine("Modificación horas laborales");
                Console.WriteLine("");
                Console.ReadKey();
                Console.Clear();
                ModificarHorario();
                break;

            case 3:
                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine("Modificación gestión de vacaciones");
                Console.WriteLine("");
                Console.ReadKey();
                Console.Clear();
                ModificarHorario();
                break;

            case 4:
                Console.Clear();
                Menu_2();
                break;

            default:
                Console.WriteLine("Usted ha seleccionado una opción inválida. Seleccione una opción correcta.");
                Console.ReadKey();
                Console.Clear();
                ModificarHorario();
                break;
        }
    }

    static void ManualDeUsuario()
    {
        Console.WriteLine("-------------------------------------------------------");
        Console.WriteLine("Manual de usuario:");
        Console.WriteLine("");
        Console.WriteLine("I Opciones que posee el programa");
        Console.WriteLine("1. proceso principal");
        Console.WriteLine("2. Manual de usuario");
        Console.WriteLine("3. Creditos");
        Console.WriteLine("4. Salir");
        Console.WriteLine("");
        Console.WriteLine("II Pasos a seguir para mostrar la solucion");
        Console.WriteLine("1. Seleccionar la opcion de proceso principal");
        Console.WriteLine("2. Seleccionar opcion por opcion hasta leer todas las descripciones que se les brindara");
        Console.WriteLine("3. Una vez leida las descripciones detalladas que les brindara las primeras tres opciones");
        Console.WriteLine("   seleccionar la cuarta opcion para Modificar el horario deseado");
        Console.WriteLine("4. Complete su modificacion del horario deseado");
        Console.WriteLine("5. Podra decidir si usted desea regresar al menu anterior o al menu principal");
        Console.WriteLine("");
        Console.WriteLine("III Proposito de este programa");
        Console.WriteLine("El proposito de este programa 'Planificacion de horarios de jornadas laborales un una empresa' tiene como objetivo: ");
        Console.WriteLine("Realizar un programa en el cual el trabajador pueda crear y organizar su horario basandose,");
        Console.WriteLine("en las propuestas que se le daran.");
        Console.WriteLine("");


        string regresarMenuPrincipal;
        do
        {
            Console.WriteLine("¿Desea regresar al Menú Principal? (si/no)");
            regresarMenuPrincipal = Console.ReadLine();

            if (regresarMenuPrincipal.ToLower() == "si")
            {
                Console.Clear();
                Menu_1();
                break;
            }
            else if (regresarMenuPrincipal.ToLower() == "no")
            {
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Opción no válida. Introduce 'si' o 'no'.");
            }
        } while (true);
    }

    static void Creditos()
    {

        Console.WriteLine("-----------------------------------------------------------------");
        Console.WriteLine("Créditos:");
        Console.WriteLine("");
        Console.WriteLine("Planificacion de horarios de jornadas laborales un una empresa");
        Console.WriteLine("");
        Console.WriteLine("Fecha de creacion: 20 de Octubre del 2023");
        Console.WriteLine("");
        Console.WriteLine("El tiempo estimado de creacion del programa fue de 5 Horas");
        Console.WriteLine("");
        Console.WriteLine("Prgrama creado por:");
        Console.WriteLine("");
        Console.WriteLine("Derick Pinto");
        Console.WriteLine("1065723");
        Console.WriteLine("Ingenieria Industrial");
        Console.WriteLine("");
        Console.WriteLine("Nicolas Rivas");
        Console.WriteLine("1045123");
        Console.WriteLine("Ingenieria Industrial");
        Console.WriteLine("");
        Console.WriteLine("Maria Reneé del leon");
        Console.WriteLine("1066423");
        Console.WriteLine("Ingenieria Industrial");
        Console.WriteLine("");


        string regresarMenuPrincipal;
        do
        {
            Console.WriteLine("¿Desea regresar al Menú Principal? (si/no)");
            regresarMenuPrincipal = Console.ReadLine();

            if (regresarMenuPrincipal.ToLower() == "si")
            {
                Console.Clear();
                Menu_1();
                break;
            }
            else if (regresarMenuPrincipal.ToLower() == "no")
            {
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Opción no válida. Introduce 'si' o 'no'.");
            }
        } while (true);
    }
}