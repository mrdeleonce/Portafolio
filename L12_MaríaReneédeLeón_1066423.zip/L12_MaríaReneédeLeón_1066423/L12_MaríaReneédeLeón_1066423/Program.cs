﻿string[] numeros = new string[10];


for (int i = 0; i < 10; i++)
{
    Console.Write("Ingrese 10 números: ");
    numeros[i] = Console.ReadLine();
}


string min = numeros[0];
string max = numeros[0];
int sumaTotal = 0;
int sumaPares = 0;
int sumaImpares = 0;


for (int i = 0; i < 10; i++)
{

    sumaTotal = sumaTotal + Convert.ToInt32(numeros[i]);


    if (Convert.ToInt32(numeros[i]) < Convert.ToInt32(min))
    {
        min = numeros[i];
    }

    if (Convert.ToInt32(numeros[i]) > Convert.ToInt32(max))
    {
        max = numeros[i];
    }


    if (i % 2 == 0)
    {
        sumaPares = sumaPares + Convert.ToInt32(numeros[i]);
    }
    else
    {
        sumaImpares = sumaImpares + Convert.ToInt32(numeros[i]);
    }
}


double promedio = sumaTotal / 10;


Console.WriteLine("Número más pequeño: " + min);
Console.WriteLine("Número más grande: " + max);
Console.WriteLine("Suma total: " + sumaTotal);
Console.WriteLine("Promedio: " + promedio);

Console.Write("Números ordenados por posición: ");
for (int i = 0; i < 10; i++)
{
    Console.Write(numeros[i] + " ");
}
Console.WriteLine(" ");

Console.WriteLine("Suma de posiciones pares: " + sumaPares);
Console.WriteLine("Suma de posiciones impares: " + sumaImpares);

Console.ReadLine()
